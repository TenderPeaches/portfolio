var currentPage = document.getElementsByClassName("header__banner-title")[0];

currentPage.addEventListener('click', function(event) {
	var otherPages = document.getElementsByClassName("header__menu-button");
	var shownPages = document.getElementsByClassName("header__menu-button--shown");

	if (shownPages.length == 0) {
		for (var i = 0; i < otherPages.length; ++i) {
			otherPages[i].classList.add("header__menu-button--shown");
		}
	} 
	else {
		for (var i = 0; i < otherPages.length; ++i) {
			otherPages[i].classList.remove("header__menu-button--shown");
		}
	}
});
